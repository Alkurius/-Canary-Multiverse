<?php

use Twig\Profiler\Profile;

class_exists('Twig\Profiler\Profile');

if (\false) {
    class Twig_Profiler_Profile extends Profile
    {
    }
}
