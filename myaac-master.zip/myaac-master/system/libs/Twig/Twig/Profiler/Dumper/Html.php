<?php

use Twig\Profiler\Dumper\HtmlDumper;

class_exists('Twig\Profiler\Dumper\HtmlDumper');

if (\false) {
    class Twig_Profiler_Dumper_Html extends HtmlDumper
    {
    }
}
