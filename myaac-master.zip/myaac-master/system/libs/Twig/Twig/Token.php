<?php

use Twig\Token;

class_exists('Twig\Token');

if (\false) {
    class Twig_Token extends Token
    {
    }
}
