<?php

use Twig\Node\TextNode;

class_exists('Twig\Node\TextNode');

if (\false) {
    class Twig_Node_Text extends TextNode
    {
    }
}
