<?php

use Twig\Node\Expression\Binary\LessBinary;

class_exists('Twig\Node\Expression\Binary\LessBinary');

if (\false) {
    class Twig_Node_Expression_Binary_Less extends LessBinary
    {
    }
}
