<?php

use Twig\Node\NodeCaptureInterface;

class_exists('Twig\Node\NodeCaptureInterface');

if (\false) {
    class Twig_NodeCaptureInterface extends NodeCaptureInterface
    {
    }
}
