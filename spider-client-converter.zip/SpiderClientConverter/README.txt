Sources available in:
https://github.com/Arch-Mina/ClientConverter

Credits to Arch-Mina.
